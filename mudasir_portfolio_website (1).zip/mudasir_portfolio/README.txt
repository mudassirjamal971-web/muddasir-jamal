# Mudasir Jamal — IT Portfolio

## Run locally
1. Extract the ZIP file.
2. Open the `mudasir_portfolio` folder.
3. Double-click `index.html` to open it in a browser.

No build tools or installation are required.

## Before publishing
- Replace `YOUR_EMAIL@example.com` in `index.html` with your professional email.
- Replace the LinkedIn and GitHub links with your actual profile URLs.
- Add project screenshots and GitHub repository links for projects you have actually completed.
- Check the education, training and experience details for accuracy.
- Add a professional photo only if you want one.

## Files
- `index.html` — page content and sections
- `style.css` — responsive black-and-blue design
- `script.js` — mobile navigation and current year

The Google Fonts import requires an internet connection. The site still works with fallback fonts if offline.
